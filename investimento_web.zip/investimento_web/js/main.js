/**
 * Investimento Premium - Script Principal
 * Funcionalidades interativas para a página de apresentação
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar AOS (Animate on Scroll)
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });

    // Inicializar Swiper para galeria de imagens
    const propertyGallery = new Swiper('.property-gallery', {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        autoplay: {
            delay: 5000,
        },
    });

    // Barra de progresso de leitura
    window.addEventListener('scroll', function() {
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        document.getElementById('progressBar').style.width = scrolled + '%';
    });

    // Botão Voltar ao Topo
    const backToTopButton = document.getElementById('backToTop');
    
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopButton.classList.add('active');
        } else {
            backToTopButton.classList.remove('active');
        }
    });
    
    backToTopButton.addEventListener('click', function(e) {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Navegação suave para links âncora
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Destacar item de menu ativo durante a rolagem
    const sections = document.querySelectorAll('section[id]');
    
    window.addEventListener('scroll', function() {
        const scrollY = window.pageYOffset;
        
        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 100;
            const sectionId = section.getAttribute('id');
            
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                document.querySelector('.navbar-nav a[href*=' + sectionId + ']').classList.add('active');
            } else {
                document.querySelector('.navbar-nav a[href*=' + sectionId + ']').classList.remove('active');
            }
        });
    });

    // Mudar cor da navbar ao rolar
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.style.backgroundColor = 'rgba(13, 47, 98, 0.95)';
            navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.backgroundColor = 'rgba(13, 47, 98, 0.95)';
            navbar.style.boxShadow = 'none';
        }
    });

    // Gráficos com Chart.js
    // Gráfico do Mercado Imobiliário
    const marketCtx = document.getElementById('marketChart').getContext('2d');
    const marketChart = new Chart(marketCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
            datasets: [{
                label: 'Valorização Imobiliária 2025',
                data: [0.8, 0.9, 1.1, 0.7, 1.2, 0.9, 1.0, 1.3, 0.8, 1.1, 0.9, 1.0],
                backgroundColor: 'rgba(30, 87, 153, 0.2)',
                borderColor: 'rgba(30, 87, 153, 1)',
                borderWidth: 2,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Valorização Mensal (%)'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Gráfico das Regiões
    const regionsCtx = document.getElementById('regionsChart').getContext('2d');
    const regionsChart = new Chart(regionsCtx, {
        type: 'bar',
        data: {
            labels: ['Entorno do Aeroporto', 'Quississana', 'Costeira', 'Jardim Suíça'],
            datasets: [{
                label: 'Valorização Projetada em 5 anos (%)',
                data: [95.3, 88.7, 86.2, 83.5],
                backgroundColor: [
                    'rgba(212, 175, 55, 0.8)',
                    'rgba(30, 87, 153, 0.7)',
                    'rgba(30, 87, 153, 0.6)',
                    'rgba(30, 87, 153, 0.5)'
                ],
                borderColor: [
                    'rgba(212, 175, 55, 1)',
                    'rgba(30, 87, 153, 1)',
                    'rgba(30, 87, 153, 1)',
                    'rgba(30, 87, 153, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Valorização Projetada por Região'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Gráfico do Airbnb
    const airbnbCtx = document.getElementById('airbnbChart').getContext('2d');
    const airbnbChart = new Chart(airbnbCtx, {
        type: 'line',
        data: {
            labels: ['2025', '2026', '2027', '2028', '2029', '2030'],
            datasets: [
                {
                    label: 'Oferta (Unidades)',
                    data: [100, 110, 125, 145, 170, 200],
                    borderColor: 'rgba(30, 87, 153, 1)',
                    backgroundColor: 'rgba(30, 87, 153, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'Demanda (Unidades)',
                    data: [105, 125, 150, 180, 210, 240],
                    borderColor: 'rgba(212, 175, 55, 1)',
                    backgroundColor: 'rgba(212, 175, 55, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Projeção de Oferta vs Demanda Airbnb'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Calculadora de Investimento
    const unitsInput = document.getElementById('unitsInput');
    const entryPercentInput = document.getElementById('entryPercentInput');
    const entryPercentValue = document.getElementById('entryPercentValue');
    const monthlyRevenueInput = document.getElementById('monthlyRevenueInput');
    const calculateBtn = document.getElementById('calculateBtn');
    
    // Atualizar valor do percentual de entrada
    entryPercentInput.addEventListener('input', function() {
        entryPercentValue.textContent = this.value + '%';
    });
    
    // Calcular retorno do investimento
    calculateBtn.addEventListener('click', function() {
        const units = parseInt(unitsInput.value);
        const entryPercent = parseInt(entryPercentInput.value);
        const monthlyRevenue = parseInt(monthlyRevenueInput.value);
        
        const unitPrice = 270000;
        const totalInvestment = unitPrice * units;
        const entryValue = totalInvestment * (entryPercent / 100);
        const financingValue = totalInvestment - entryValue;
        
        // Estimativa simplificada da parcela mensal (3% do saldo financiado dividido por 80 meses)
        const monthlyPayment = (financingValue * 0.03) / 80;
        const totalMonthlyRevenue = monthlyRevenue * units;
        const netCashFlow = totalMonthlyRevenue - monthlyPayment;
        const annualROI = (netCashFlow * 12 / entryValue) * 100;
        
        // Atualizar resultados na interface
        document.getElementById('totalInvestment').textContent = formatCurrency(totalInvestment);
        document.getElementById('entryValue').textContent = formatCurrency(entryValue);
        document.getElementById('financingValue').textContent = formatCurrency(financingValue);
        document.getElementById('monthlyPayment').textContent = formatCurrency(monthlyPayment);
        document.getElementById('totalMonthlyRevenue').textContent = formatCurrency(totalMonthlyRevenue);
        document.getElementById('netCashFlow').textContent = formatCurrency(netCashFlow);
        document.getElementById('annualROI').textContent = Math.round(annualROI) + '%';
    });
    
    // Função para formatar valores monetários
    function formatCurrency(value) {
        return 'R$ ' + value.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }

    // Formulário de Contato
    const contactForm = document.getElementById('contactForm');
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Simulação de envio do formulário
        const submitButton = this.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        
        submitButton.disabled = true;
        submitButton.textContent = 'Enviando...';
        
        // Simular processamento
        setTimeout(function() {
            submitButton.textContent = 'Enviado com Sucesso!';
            
            // Limpar formulário
            contactForm.reset();
            
            // Restaurar botão após alguns segundos
            setTimeout(function() {
                submitButton.disabled = false;
                submitButton.textContent = originalText;
            }, 3000);
        }, 1500);
    });
});

